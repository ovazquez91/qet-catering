<section
                                            class="elementor-section elementor-top-section elementor-element elementor-element-ea812cf elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                            data-id="ea812cf"
                                            data-element_type="section"
                                            data-settings='{"craftcoffee_ext_is_background_parallax":"false"}'
                                        >
                                            <div class="elementor-container elementor-column-gap-default">
                                                <div class="elementor-row">
                                                    <div
                                                        class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-feaaa0e"
                                                        data-id="feaaa0e"
                                                        data-element_type="column"
                                                        data-settings='{"craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_is_smoove":"false","craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false","craftcoffee_ext_is_fadeout_animation":"false"}'
                                                    >
                                                        <div class="elementor-column-wrap elementor-element-populated">
                                                            <div class="elementor-widget-wrap">
                                                                <div
                                                                    class="elementor-element elementor-element-c411cf0 elementor-widget__width-auto elementor-widget elementor-widget-spacer"
                                                                    data-id="c411cf0"
                                                                    data-element_type="widget"
                                                                    data-settings='{"craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_is_smoove":"false","craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false","craftcoffee_ext_is_fadeout_animation":"false"}'
                                                                    data-widget_type="spacer.default"
                                                                >
                                                                    <div class="elementor-widget-container">
                                                                        <div class="elementor-spacer">
                                                                            <div class="elementor-spacer-inner"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div
                                                                    class="elementor-element elementor-element-efe116b elementor-widget elementor-widget-heading"
                                                                    data-id="efe116b"
                                                                    data-element_type="widget"
                                                                    data-settings='{"craftcoffee_ext_is_smoove":"true","craftcoffee_ext_smoove_disable":"769","craftcoffee_ext_smoove_duration":1000,"craftcoffee_ext_smoove_scalex":{"unit":"px","size":0,"sizes":[]},"craftcoffee_ext_smoove_scaley":{"unit":"px","size":0,"sizes":[]},"craftcoffee_ext_smoove_translatey":{"unit":"px","size":100,"sizes":[]},"craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_smoove_rotatex":{"unit":"px","size":0,"sizes":[]},"craftcoffee_ext_smoove_rotatey":{"unit":"px","size":0,"sizes":[]},"craftcoffee_ext_smoove_rotatez":{"unit":"px","size":0,"sizes":[]},"craftcoffee_ext_smoove_translatex":{"unit":"px","size":0,"sizes":[]},"craftcoffee_ext_smoove_translatez":{"unit":"px","size":0,"sizes":[]},"craftcoffee_ext_smoove_skewx":{"unit":"px","size":0,"sizes":[]},"craftcoffee_ext_smoove_skewy":{"unit":"px","size":0,"sizes":[]},"craftcoffee_ext_smoove_perspective":{"unit":"px","size":1000,"sizes":[]},"craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false"}'
                                                                    data-widget_type="heading.default"
                                                                >
                                                                    <div class="elementor-widget-container">
                                                                        <h3 class="elementor-heading-title elementor-size-default">Nuestro</h3>
                                                                    </div>
                                                                </div>
                                                                <div
                                                                    class="elementor-element elementor-element-b22170b elementor-widget__width-inherit elementor-absolute elementor-widget elementor-widget-image"
                                                                    data-id="b22170b"
                                                                    data-element_type="widget"
                                                                    data-settings='{"_position":"absolute","craftcoffee_ext_is_smoove":"false","craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false"}'
                                                                    data-widget_type="image.default"
                                                                >
                                                                    <div class="elementor-widget-container">
                                                                        <div class="elementor-image">
                                                                            <img
                                                                                width="180"
                                                                                height="443"
                                                                                src="upload/coffee-bg-3-e1592385684436.png"
                                                                                class="attachment-full size-full"
                                                                                alt=""
                                                                                loading="lazy"
                                                                            />
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div
                                                                    class="elementor-element elementor-element-6a1c1da elementor-widget elementor-widget-heading"
                                                                    data-id="6a1c1da"
                                                                    data-element_type="widget"
                                                                    data-settings='{"craftcoffee_ext_is_smoove":"true","craftcoffee_ext_smoove_disable":"769","craftcoffee_ext_smoove_duration":1000,"craftcoffee_ext_smoove_scalex":{"unit":"px","size":2,"sizes":[]},"craftcoffee_ext_smoove_scaley":{"unit":"px","size":2,"sizes":[]},"craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_smoove_rotatex":{"unit":"px","size":0,"sizes":[]},"craftcoffee_ext_smoove_rotatey":{"unit":"px","size":0,"sizes":[]},"craftcoffee_ext_smoove_rotatez":{"unit":"px","size":0,"sizes":[]},"craftcoffee_ext_smoove_translatex":{"unit":"px","size":0,"sizes":[]},"craftcoffee_ext_smoove_translatey":{"unit":"px","size":0,"sizes":[]},"craftcoffee_ext_smoove_translatez":{"unit":"px","size":0,"sizes":[]},"craftcoffee_ext_smoove_skewx":{"unit":"px","size":0,"sizes":[]},"craftcoffee_ext_smoove_skewy":{"unit":"px","size":0,"sizes":[]},"craftcoffee_ext_smoove_perspective":{"unit":"px","size":1000,"sizes":[]},"craftcoffee_ext_is_infinite":"false"}'
                                                                    data-widget_type="heading.default"
                                                                >
                                                                    <div class="elementor-widget-container">
                                                                        <h1 class="elementor-heading-title elementor-size-default">Menú</h1>
                                                                    </div>
                                                                </div>
                                                                <div
                                                                    class="elementor-element elementor-element-6c407bf elementor-widget__width-inherit elementor-absolute elementor-widget elementor-widget-image"
                                                                    data-id="6c407bf"
                                                                    data-element_type="widget"
                                                                    data-settings='{"_position":"absolute","craftcoffee_ext_is_smoove":"false","craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false","craftcoffee_ext_is_fadeout_animation":"false"}'
                                                                    data-widget_type="image.default"
                                                                >
                                                                    <div class="elementor-widget-container">
                                                                        <div class="elementor-image">
                                                                            <img
                                                                                width="350"
                                                                                height="269"
                                                                                src="upload/coffee-bg-2-e1592389807271.png"
                                                                                class="attachment-full size-full"
                                                                                alt=""
                                                                                loading="lazy"
                                                                            />
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </section>
                                        <section
                                            class="elementor-section elementor-top-section elementor-element elementor-element-52dc38a elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                            data-id="52dc38a"
                                            data-element_type="section"
                                            data-settings='{"craftcoffee_ext_is_background_parallax":"false"}'
                                        >
                                            <div class="elementor-container elementor-column-gap-default">
                                                <div class="elementor-row">
                                                    <div
                                                        class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-c9f3e7c"
                                                        data-id="c9f3e7c"
                                                        data-element_type="column"
                                                        data-settings='{"craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_is_smoove":"false","craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false","craftcoffee_ext_is_fadeout_animation":"false"}'
                                                    >
                                                        <div class="elementor-column-wrap elementor-element-populated">
                                                            <div class="elementor-widget-wrap">
                                                                <div
                                                                    class="elementor-element elementor-element-6cd32de elementor-widget elementor-widget-heading"
                                                                    data-id="6cd32de"
                                                                    data-element_type="widget"
                                                                    data-settings='{"craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_is_smoove":"false","craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false","craftcoffee_ext_is_fadeout_animation":"false"}'
                                                                    data-widget_type="heading.default"
                                                                >
                                                                    <div class="elementor-widget-container">
                                                                        <h2 class="elementor-heading-title elementor-size-default">Hot Coffees</h2>
                                                                    </div>
                                                                </div>
                                                                <div
                                                                    class="elementor-element elementor-element-6a86839 elementor-widget elementor-widget-craftcoffee-food-menu"
                                                                    data-id="6a86839"
                                                                    data-element_type="widget"
                                                                    data-settings='{"craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_is_smoove":"false","craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false","craftcoffee_ext_is_fadeout_animation":"false"}'
                                                                    data-widget_type="craftcoffee-food-menu.default"
                                                                >
                                                                    <div class="elementor-widget-container">
                                                                        <div class="food-menu-container">
                                                                            <div class="food-menu-content-wrapper food-menu">
                                                                                <div class="food-menu-grid-wrapper food-tooltip food-menu-1" data-tooltip-content="#tooltip-content-6a86839-1">
                                                                                    

                                                                                    <div class="food-menu-content">
                                                                                        <div class="food-menu-content-top-holder">
                                                                                            <div class="food-menu-content-title-holder">
                                                                                                <h3 class="food-menu-title">Cafe Americano</h3>
                                                                                            </div>

                                                                                            <div class="food-menu-content-title-line"></div>

                                                                                            <div class="food-menu-content-price-holder">
                                                                                                <span class="food-menu-content-price-sale"> $7 </span>

                                                                                                <span class="food-menu-content-price-normal"> $9 </span>
                                                                                            </div>
                                                                                        </div>

                                                                                        <div class="food-menu-desc">Espresso shots topped with hot water</div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="food-menu-grid-wrapper food-tooltip food-menu-2" data-tooltip-content="#tooltip-content-6a86839-2">
                                                                                   

                                                                                    <div class="food-menu-content">
                                                                                        <div class="food-menu-content-top-holder">
                                                                                            <div class="food-menu-content-title-holder">
                                                                                                <h3 class="food-menu-title">Cappuccino</h3>
                                                                                            </div>

                                                                                            <div class="food-menu-content-title-line"></div>

                                                                                            <div class="food-menu-content-price-holder">
                                                                                                <span class="food-menu-content-price-normal"> $9 </span>
                                                                                            </div>
                                                                                        </div>

                                                                                        <div class="food-menu-desc">Dark espresso lies in wait under milk foam</div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="food-menu-grid-wrapper food-tooltip food-menu-3 food-menu-highlight" data-tooltip-content="#tooltip-content-6a86839-3">
                                                                                    
                                                                                    <div class="food-menu-img">
                                                                                        <img src="upload/ec519dd5642c41629194192cce582135_result-150x150.jpg" alt="" />
                                                                                    </div>

                                                                                    <div class="food-menu-content menu-highlight">
                                                                                        <div class="food-menu-content-top-holder">
                                                                                            <div class="food-menu-content-title-holder">
                                                                                                <h3 class="food-menu-title">Espresso</h3>
                                                                                            </div>

                                                                                            <div class="food-menu-content-title-line"></div>

                                                                                            <div class="food-menu-content-price-holder">
                                                                                                <span class="food-menu-content-price-normal"> $5 </span>
                                                                                            </div>
                                                                                        </div>

                                                                                        <div class="food-menu-desc">Signature Espresso Roast with rich flavor</div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="food-menu-grid-wrapper food-tooltip food-menu-4" data-tooltip-content="#tooltip-content-6a86839-4">
                                                                                    

                                                                                    <div class="food-menu-img">
                                                                                        <img src="upload/58db701349cb48738069e8c912e2b3ac_result-150x150.jpg" alt="" />
                                                                                    </div>

                                                                                    <div class="food-menu-content">
                                                                                        <div class="food-menu-content-top-holder">
                                                                                            <div class="food-menu-content-title-holder">
                                                                                                <h3 class="food-menu-title">Caramel Macchiato</h3>
                                                                                            </div>

                                                                                            <div class="food-menu-content-title-line"></div>

                                                                                            <div class="food-menu-content-price-holder">
                                                                                                <span class="food-menu-content-price-normal"> $9 </span>
                                                                                            </div>
                                                                                        </div>

                                                                                        <div class="food-menu-desc">Freshly steamed milk with vanilla-flavored syrup</div>
                                                                                    </div>
                                                                                </div>

                                                                                
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div
                                                        class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-61d58b4"
                                                        data-id="61d58b4"
                                                        data-element_type="column"
                                                        data-settings='{"craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_is_smoove":"false","craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false","craftcoffee_ext_is_fadeout_animation":"false"}'
                                                    >
                                                        <div class="elementor-column-wrap elementor-element-populated">
                                                            <div class="elementor-widget-wrap">
                                                                <div
                                                                    class="elementor-element elementor-element-99e2131 elementor-widget elementor-widget-heading"
                                                                    data-id="99e2131"
                                                                    data-element_type="widget"
                                                                    data-settings='{"craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_is_smoove":"false","craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false","craftcoffee_ext_is_fadeout_animation":"false"}'
                                                                    data-widget_type="heading.default"
                                                                >
                                                                    <div class="elementor-widget-container">
                                                                        <h2 class="elementor-heading-title elementor-size-default">Cold Coffees</h2>
                                                                    </div>
                                                                </div>
                                                                <div
                                                                    class="elementor-element elementor-element-7ac7369 elementor-widget elementor-widget-craftcoffee-food-menu"
                                                                    data-id="7ac7369"
                                                                    data-element_type="widget"
                                                                    data-settings='{"craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_is_smoove":"false","craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false","craftcoffee_ext_is_fadeout_animation":"false"}'
                                                                    data-widget_type="craftcoffee-food-menu.default"
                                                                >
                                                                    <div class="elementor-widget-container">
                                                                        <div class="food-menu-container">
                                                                            <div class="food-menu-content-wrapper food-menu">
                                                                                <div class="food-menu-grid-wrapper food-tooltip food-menu-1" data-tooltip-content="#tooltip-content-7ac7369-1">
                                                                                    

                                                                                    <div class="food-menu-content">
                                                                                        <div class="food-menu-content-top-holder">
                                                                                            <div class="food-menu-content-title-holder">
                                                                                                <h3 class="food-menu-title">Iced Coffee with Milk</h3>
                                                                                            </div>

                                                                                            <div class="food-menu-content-title-line"></div>

                                                                                            <div class="food-menu-content-price-holder">
                                                                                                <span class="food-menu-content-price-sale"> $7 </span>

                                                                                                <span class="food-menu-content-price-normal"> $9 </span>
                                                                                            </div>
                                                                                        </div>

                                                                                        <div class="food-menu-desc">Iced Coffee Blend with milk served chilled</div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="food-menu-grid-wrapper food-tooltip food-menu-2" data-tooltip-content="#tooltip-content-7ac7369-2">
                                                                                   
                                                                                    <div class="food-menu-content">
                                                                                        <div class="food-menu-content-top-holder">
                                                                                            <div class="food-menu-content-title-holder">
                                                                                                <h3 class="food-menu-title">Iced Espresso</h3>
                                                                                            </div>

                                                                                            <div class="food-menu-content-title-line"></div>

                                                                                            <div class="food-menu-content-price-holder">
                                                                                                <span class="food-menu-content-price-normal"> $9 </span>
                                                                                            </div>
                                                                                        </div>

                                                                                        <div class="food-menu-desc">Smooth signature Espresso Roast over ice boasts</div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="food-menu-grid-wrapper food-tooltip food-menu-3" data-tooltip-content="#tooltip-content-7ac7369-3">
                                                                                    
                                                                                    <div class="food-menu-content">
                                                                                        <div class="food-menu-content-top-holder">
                                                                                            <div class="food-menu-content-title-holder">
                                                                                                <h3 class="food-menu-title">Iced Caramel Macchiato</h3>
                                                                                            </div>

                                                                                            <div class="food-menu-content-title-line"></div>

                                                                                            <div class="food-menu-content-price-holder">
                                                                                                <span class="food-menu-content-price-normal"> $7 </span>
                                                                                            </div>
                                                                                        </div>

                                                                                        <div class="food-menu-desc">Signature caramel crosshatch and a mocha drizzle</div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="food-menu-grid-wrapper food-tooltip food-menu-4 food-menu-highlight" data-tooltip-content="#tooltip-content-7ac7369-4">
                                                                                    

                                                                                    <div class="food-menu-content-highlight-holder">
                                                                                        <h4>Barista Recommended</h4>
                                                                                    </div>

                                                                                    <div class="food-menu-content menu-highlight">
                                                                                        <div class="food-menu-content-top-holder">
                                                                                            <div class="food-menu-content-title-holder">
                                                                                                <h3 class="food-menu-title">Flat Milk</h3>
                                                                                            </div>

                                                                                            <div class="food-menu-content-title-line"></div>

                                                                                            <div class="food-menu-content-price-holder">
                                                                                                <span class="food-menu-content-price-normal"> $9 </span>
                                                                                            </div>
                                                                                        </div>

                                                                                        <div class="food-menu-desc">Fresh brewed coffee and steamed milk</div>
                                                                                    </div>
                                                                                </div>
                                                                                
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                </div>
                                                
                                            </div>
                                            <a style="margin-bottom: 100px; width: 100%;" class="button" href="nosotros.php"> Ver menú completo </a>
                                        </section>