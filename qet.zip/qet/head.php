<head>

    <title>qet</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <link rel="stylesheet" href="css/reset.css" type="text/css" media="all" />
    <link rel="stylesheet" href="css/wordpress.css" type="text/css" media="all" />
    <link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
    <link rel="stylesheet" href="css/modulobox.css" type="text/css" media="all" />
    <link rel="stylesheet" href="css/left-align-menu.css" type="text/css" media="all" />
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css" media="all" />
    <link rel="stylesheet" href="css/themify-icons.css" type="text/css" media="all" />
    <link rel="stylesheet" href="css/tooltipster.css" type="text/css" media="all" />
    <link rel="stylesheet" href="css/demo.css" type="text/css" media="all" />
    <link rel="stylesheet" href="js/plugins/loftloader/assets/css/loftloader.min.css" type="text/css" media="all" />
    <link rel="stylesheet" href="js/plugins/elementor/assets/lib/animations/animations.min.css" type="text/css" media="all" />
    <link rel="stylesheet" href="js/plugins/elementor/assets/css/frontend-legacy.min.css" type="text/css" media="all" />
    <link rel="stylesheet" href="js/plugins/elementor/assets/css/frontend.min.css" type="text/css" media="all" />
    <link rel="stylesheet" href="js/plugins/craftcoffee-elementor/assets/css/swiper.css" type="text/css" media="all" />
    <link rel="stylesheet" href="js/plugins/craftcoffee-elementor/assets/css/justifiedGallery.css" type="text/css" media="all" />
    <link rel="stylesheet" href="js/plugins/craftcoffee-elementor/assets/css/flickity.css" type="text/css" media="all" />
    <link rel="stylesheet" href="js/plugins/craftcoffee-elementor/assets/css/owl.theme.default.min.css" type="text/css" media="all" />
    <link rel="stylesheet" href="js/plugins/craftcoffee-elementor/assets/css/switchery.css" type="text/css" media="all" />
    <link rel="stylesheet" href="js/plugins/craftcoffee-elementor/assets/css/craftcoffee-elementor.css" type="text/css" media="all" />
    <link rel="stylesheet" href="js/plugins/craftcoffee-elementor/assets/css/craftcoffee-elementor-responsive.css" type="text/css" media="all" />
    <link rel="stylesheet" href="css/responsive.css" type="text/css" media="all" />
    <link rel="stylesheet" href="js/plugins/elementor/assets/lib/font-awesome/css/fontawesome.min.css" type="text/css" media="all" />
    <link rel="stylesheet" href="js/plugins/elementor/assets/lib/font-awesome/css/brands.min.css" type="text/css" media="all" />
    <link rel="stylesheet" href="js/plugins/elementor/assets/lib/font-awesome/css/solid.min.css" type="text/css" media="all" />
    <link rel="stylesheet" href="css/custom-css.min.css" type="text/css" media="all" />
    <link rel="icon" href="imagenes/flaticon.png" sizes="32x32" />
    <link rel="icon" href="imagenes/tg-thumb-faticon.png" sizes="192x192" />
    <link rel="apple-touch-icon" href="imagenes/tg-flaticon.png" />
    <meta name="msapplication-TileImage" content="imagenes/cropped-TG-Thumb-falticon.png" />

</head>