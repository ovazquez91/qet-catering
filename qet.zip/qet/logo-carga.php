<!-- carga logo -->
<div id="loftloader-wrapper" class="pl-imgloading" data-show-close-time="15000" data-max-load-time="0">
        <div class="loader-inner">
            <div id="loader">
                <div class="imgloading-container"><span style="background-image: url(imagenes/logo.png);"></span></div>
                <img data-no-lazy="1" class="skip-lazy" alt="loader image" src="imagenes/logo.png" />
            </div>
        </div>
        <div class="loader-section section-fade"></div>
        <div class="loader-close-button" style="display: none;"><span class="screen-reader-text">X</span></div>
    </div>
    <!-- carga logo -->