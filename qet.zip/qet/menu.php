<div id="elementor-header" class="main-menu-wrapper">
                <div data-elementor-type="wp-post" data-elementor-id="3099" class="elementor custom-css-style" data-elementor-settings="[]">
                    <div class="elementor-inner">
                        <div class="elementor-section-wrap">
                            <section
                                class="elementor-section elementor-top-section elementor-element elementor-element-a216edb elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                data-id="a216edb"
                                data-element_type="section"
                                data-settings='{"craftcoffee_ext_is_background_parallax":"false"}'
                            >
                                <div class="elementor-container elementor-column-gap-default">
                                    <div class="elementor-row">
                                        <div
                                            class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-eb2db78 elementor-hidden-tablet elementor-hidden-phone"
                                            data-id="eb2db78"
                                            data-element_type="column"
                                            data-settings='{"craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_is_smoove":"false","craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false","craftcoffee_ext_is_fadeout_animation":"false"}'
                                        >
                                            <div class="elementor-column-wrap elementor-element-populated">
                                                <div class="elementor-widget-wrap">
                                                    <div
                                                        class="elementor-element elementor-element-d6b5ce3 elementor-widget elementor-widget-craftcoffee-navigation-menu"
                                                        data-id="d6b5ce3"
                                                        data-element_type="widget"
                                                        data-settings='{"craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_is_smoove":"false","craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false","craftcoffee_ext_is_fadeout_animation":"false"}'
                                                        data-widget_type="craftcoffee-navigation-menu.default"
                                                    >
                                                        <div class="elementor-widget-container">
                                                            <div class="themegoods-navigation-wrapper menu_style1">
                                                                <div class="menu-main-menu-container">
                                                                    <ul id="nav_menu34" class="nav">
                                                                        <li class="menu-item current-menu-ancestor current-menu-parent">
                                                                            <a href="index.php">Inicio</a>
                                                                        </li>
                                                                        <li class="menu-item current-menu-ancestor current-menu-parent">
                                                                            <a href="nosotros.php">Nosotros</a>
                                                                        </li>
                                                                        <li class="menu-item current-menu-ancestor current-menu-parent">
                                                                            <a href="servicios.php">Servicios</a>
                                                                        </li>
                                                                        <li class="menu-item menu-item-has-children arrow">
                                                                            <a href="#">Extras</a>
                                                                            <ul class="sub-menu">
                                                                                <li class="menu-item"><a href="anuncio-de-privacidad.php">Anuncio de Privacidad</a></li>
                                                                                <li class="menu-item"><a href="queretaro.php">Querétaro</a></li>
                                                                                <li class="menu-item"><a href="menu-completo.php">Menú</a></li>
                                                                            </ul>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div
                                            class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-8dfe958"
                                            data-id="8dfe958"
                                            data-element_type="column"
                                            data-settings='{"craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_is_smoove":"false","craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false","craftcoffee_ext_is_fadeout_animation":"false"}'
                                        >
                                            <div class="elementor-column-wrap elementor-element-populated">
                                                <div class="elementor-widget-wrap">
                                                    <div
                                                        class="elementor-element elementor-element-6f23744 elementor-absolute elementor-widget elementor-widget-image"
                                                        data-id="6f23744"
                                                        data-element_type="widget"
                                                        data-settings='{"_position":"absolute","craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_is_smoove":"false","craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false","craftcoffee_ext_is_fadeout_animation":"false"}'
                                                        data-widget_type="image.default"
                                                    >
                                                        <div class="elementor-widget-container">
                                                            <div class="elementor-image">
                                                                <a href="index.html">
                                                                    <img
                                                                        width="180"
                                                                        height="180"
                                                                        src="imagenes/logo.png"
                                                                        class="attachment-full size-full"
                                                                        alt=""
                                                                        loading="lazy"
                                                                    />
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div
                                            class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-b401b7a elementor-hidden-phone"
                                            data-id="b401b7a"
                                            data-element_type="column"
                                            data-settings='{"craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_is_smoove":"false","craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false","craftcoffee_ext_is_fadeout_animation":"false"}'
                                        >
                                            <div class="elementor-column-wrap elementor-element-populated">
                                                <div class="elementor-widget-wrap">
                                                    <div
                                                        class="elementor-element elementor-element-9966067 elementor-widget__width-auto elementor-shape-rounded elementor-grid-0 elementor-widget elementor-widget-social-icons"
                                                        data-id="9966067"
                                                        data-element_type="widget"
                                                        data-settings='{"craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_is_smoove":"false","craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false","craftcoffee_ext_is_fadeout_animation":"false"}'
                                                        data-widget_type="social-icons.default"
                                                    >
                                                    <div class="elementor-widget-container">
                                                    <div class="themegoods-navigation-wrapper menu_style1">
                                                                <div class="menu-main-menu-container">
                                                                    <ul id="nav_menu34" class="nav">
                                                                        <li class="menu-item current-menu-ancestor current-menu-parent">
                                                                        <img  width="16" height="16" src="icons/menu.png"> <a style="color: #fff; .themegoods-navigation-wrapper.menu_style1 .nav li > a:before { background-color: #fff;}" href="ordenar.php">Ordenar</a>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        
                                                    </div>
                                                   
                                                </div>
                                            </div>
                                        </div>
                                        <div
                                            class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-fcec661"
                                            data-id="fcec661"
                                            data-element_type="column"
                                            data-settings='{"craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_is_smoove":"false","craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false","craftcoffee_ext_is_fadeout_animation":"false"}'
                                        >
                                            <div class="elementor-column-wrap elementor-element-populated">
                                                <div class="elementor-widget-wrap">
                                                    <div
                                                        class="elementor-element elementor-element-ff52274 elementor-align-center elementor-widget-tablet__width-auto elementor-hidden-phone elementor-widget elementor-widget-button"
                                                        data-id="ff52274"
                                                        data-element_type="widget"
                                                        data-settings='{"craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_is_smoove":"false","craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false","craftcoffee_ext_is_fadeout_animation":"false"}'
                                                        data-widget_type="button.default"
                                                    >
                                                        <div class="elementor-widget-container">
                                                         <div class="themegoods-navigation-wrapper menu_style1">
                                                                <div class="menu-main-menu-container">
                                                                    <ul id="nav_menu34" class="nav">
                                                                        <li class="menu-item current-menu-ancestor current-menu-parent">
                                                                            <img  width="16" height="16" src="icons/contacto2.png"> <a style="color: #fff; .themegoods-navigation-wrapper.menu_style1 .nav li > a:before { background-color: #fff;}" href="contacto.php">Contacto</a>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="elementor-element elementor-element-0b79fea elementor_mobile_nav elementor-widget__width-auto elementor-hidden-desktop elementor-view-default elementor-widget elementor-widget-icon"
                                                        data-id="0b79fea"
                                                        data-element_type="widget"
                                                        data-settings='{"craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_is_smoove":"false","craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false","craftcoffee_ext_is_fadeout_animation":"false"}'
                                                        data-widget_type="icon.default"
                                                    >
                                                        <div class="elementor-widget-container">
                                                            <div class="elementor-icon-wrapper">
                                                                <a class="elementor-icon" href=""> <i aria-hidden="true" class="fas fa-ellipsis-v"></i> </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                            <section
                                class="elementor-section elementor-top-section elementor-element elementor-element-3727a07 elementor-section-stretched elementor-section-full_width elementor-section-height-default elementor-section-height-default"
                                data-id="3727a07"
                                data-element_type="section"
                                data-settings='{"stretch_section":"section-stretched","craftcoffee_ext_is_background_parallax":"false"}'
                            >
                                <div class="elementor-container elementor-column-gap-default">
                                    <div class="elementor-row">
                                        <div
                                            class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-f260150"
                                            data-id="f260150"
                                            data-element_type="column"
                                            data-settings='{"craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_is_smoove":"false","craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false","craftcoffee_ext_is_fadeout_animation":"false"}'
                                        >
                                            <div class="elementor-column-wrap elementor-element-populated">
                                                <div class="elementor-widget-wrap">
                                                    <div
                                                        class="elementor-element elementor-element-d00d5a2 elementor-widget-divider--view-line elementor-widget elementor-widget-divider"
                                                        data-id="d00d5a2"
                                                        data-element_type="widget"
                                                        data-settings='{"craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_is_smoove":"false","craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false","craftcoffee_ext_is_fadeout_animation":"false"}'
                                                        data-widget_type="divider.default"
                                                    >
                                                        <div class="elementor-widget-container">
                                                            <div class="elementor-divider">
                                                                <span class="elementor-divider-separator"> </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
