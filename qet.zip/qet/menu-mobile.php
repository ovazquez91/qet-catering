<!-- Menu celular -->
<a id="btn-close-mobile-menu" href="javascript:;"></a>

<div class="mobile-menu-wrapper">
    <div class="mobile-menu-content">
        <div class="menu-main-menu-container">
            <ul id="mobile_main_menu" class="mobile-main-nav">
                <li class="menu-item current-menu-ancestor current-menu-parent menu-item-has-children">
                <li class="menu-item current-menu-ancestor current-menu-parent">                                            
                    <a href="index.php">Inicio</a>
                    <a href="nosotros.php">Nosotros</a>
                    <a href="servicios.php">Servicios</a>
                    <a href="ordenar.php">Ordenar</a>
                    <a href="contacto.php">Contacto</a>
                    <ul class="sub-menu">
                        <li class="menu-item menu-item-home current-menu-item page_item page-item-4462 current_page_item">
                            <a href="index.html" aria-current="page">Extras</a>
                        </li>
                        <li class="menu-item"><a href="anuncio-de-privacidad.php">Anuncio de Privacidad</a></li>
                        <li class="menu-item"><a href="queretaro.php">Querétaro</a></li>
                        <li class="menu-item"><a href="menu-completo.php">Menú</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</div>
<!-- Menu celular -->